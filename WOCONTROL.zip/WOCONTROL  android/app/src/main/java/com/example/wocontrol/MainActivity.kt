package com.example.wocontrol

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.core.widget.TextViewCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private var watchoutIP = "192.168.0.71"
    private val apiPort = "3019"
    private val tcpPort = 3039

    private val apiClient = OkHttpClient.Builder()
        .connectTimeout(1, TimeUnit.SECONDS)
        .readTimeout(2, TimeUnit.SECONDS)
        .build()

    private val ndjsonClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var streamJob: Job? = null
    private var discoveryJob: Job? = null
    private var refreshJob: Job? = null
    private var watchdogJob: Job? = null
    private var autoRefreshJob: Job? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    private val listaIPs = mutableListOf<String>()
    private lateinit var ipAdapter: ArrayAdapter<String>
    private val botoesAtivos = mutableMapOf<String, Button>()
    private val nameToIdMap = mutableMapOf<String, String>()
    private val idToNameMap = mutableMapOf<String, String>()
    private var isConnected = false
    private var lastPressedName: String? = null
    private val currentStatusMap = mutableMapOf<String, String>()
    private val currentAudioMap = mutableMapOf<String, Boolean>()
    private val countdownMap = mutableMapOf<String, String>()
    private var lastEventTime = 0L

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val pct = if (level != -1 && scale != -1) (level * 100 / scale.toFloat()).toInt() else 0
            findViewById<TextView>(R.id.txt_battery)?.text = "🔋 $pct%"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkPermissions()

        val spinner = findViewById<Spinner>(R.id.spinner_ips)
        val editIP = findViewById<EditText>(R.id.edit_ip)
        val btnSave = findViewById<Button>(R.id.btn_save)
        val btnStop = findViewById<Button>(R.id.btn_stop_all)
        val btnRescan = findViewById<Button>(R.id.btn_rescan)
        val btnMainTimeline = findViewById<Button>(R.id.btn_main_timeline)

        editIP?.background = GradientDrawable().apply {
            cornerRadius = 30f; setColor(Color.BLACK); setStroke(3, Color.parseColor("#00FFFF"))
        }
        spinner?.background = GradientDrawable().apply {
            cornerRadius = 450f; setColor(Color.BLACK); setStroke(3, Color.parseColor("#00FFFF"))
        }
        btnStop?.background = GradientDrawable().apply {
            cornerRadius = 30f; setColor(Color.parseColor("#CC0000")); setStroke(3, Color.WHITE)
        }
        btnRescan?.background = GradientDrawable().apply {
            cornerRadius = 30f; setColor(Color.BLACK); setStroke(3, Color.parseColor("#00FFFF"))
        }
        btnMainTimeline?.background = GradientDrawable().apply {
            cornerRadius = 30f; setColor(Color.BLACK); setStroke(3, Color.parseColor("#00FFFF"))
        }

        if (!listaIPs.contains(watchoutIP)) listaIPs.add(watchoutIP)

        ipAdapter = object : ArrayAdapter<String>(this, R.layout.spinner_item, listaIPs) {
            override fun getDropDownView(position: Int, cv: View?, parent: ViewGroup): View {
                return (super.getDropDownView(position, cv, parent) as TextView).apply {
                    setTextColor(Color.parseColor("#00FFFF")); setBackgroundColor(Color.parseColor("#000020"))
                    textSize = 24f; setPadding(40, 30, 40, 30); gravity = Gravity.CENTER
                }
            }
            override fun getView(position: Int, cv: View?, parent: ViewGroup): View {
                return (super.getView(position, cv, parent) as TextView).apply {
                    setTextColor(if (isConnected) Color.parseColor("#00FF00") else Color.RED)
                    textSize = 24f; gravity = Gravity.CENTER
                }
            }
        }
        spinner?.adapter = ipAdapter

        spinner?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (watchoutIP != listaIPs[pos]) {
                    watchoutIP = listaIPs[pos]; editIP?.setText(watchoutIP)
                    startStreaming()
                    refreshTimelines()
                }
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }

        btnSave?.setOnClickListener {
            it.bounce()
            val novoIP = editIP?.text.toString().trim()
            if (novoIP.isNotEmpty()) {
                watchoutIP = novoIP
                if (!listaIPs.contains(watchoutIP)) {
                    listaIPs.add(watchoutIP); ipAdapter.notifyDataSetChanged()
                }
                spinner?.setSelection(listaIPs.indexOf(watchoutIP))
                startStreaming()
                refreshTimelines()
            }
        }

        btnStop?.setOnClickListener {
            it.bounce()
            lastPressedName = "PANIC"
            countdownMap.clear()
            currentStatusMap.clear()
            currentAudioMap.clear()
            atualizarEstiloDosBotoes()
            enviarTCP("reset")
            CoroutineScope(Dispatchers.Main).launch { delay(200); enviarTCP("kill") }
        }

        btnRescan?.setOnClickListener {
            it.bounce()
            listaIPs.clear()
            if (watchoutIP.isNotEmpty()) listaIPs.add(watchoutIP)
            ipAdapter.notifyDataSetChanged()
            startDiscovery()
            buscarInstanciasAtivas()
        }

        btnMainTimeline?.setOnClickListener {
            it.bounce()
            lastPressedName = "Main Timeline"
            atualizarEstiloDosBotoes()
            enviarTCP("run \"Main Timeline\"")
        }

        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        multicastLock = wifi.createMulticastLock("watchout_lock").apply { acquire() }

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        hideSystemUI()
        startDiscovery()
        buscarInstanciasAtivas()
        startWatchdog()
        refreshTimelines()
        startStreaming()
        startAutoRefresh()
        atualizarStatusUI()
    }

    private fun checkPermissions() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 100)
    }

    private fun atualizarStatusUI() {
        val btnSave = findViewById<Button>(R.id.btn_save) ?: return
        val btnStop = findViewById<Button>(R.id.btn_stop_all)
        val btnMain = findViewById<Button>(R.id.btn_main_timeline)
        runOnUiThread {
            btnStop?.visibility = if (isConnected) View.VISIBLE else View.GONE
            btnMain?.visibility = if (isConnected) View.VISIBLE else View.GONE
            
            if (isConnected) {
                btnSave.text = "ONLINE"; btnSave.textSize = 20f; btnSave.setTextColor(Color.BLACK)
                btnSave.background = GradientDrawable().apply {
                    cornerRadius = 160f; setColor(Color.parseColor("#00FF00")); setStroke(4, Color.parseColor("#001100"))
                }
            } else {
                btnSave.text = "CONNECT"; btnSave.textSize = 15f; btnSave.setTextColor(Color.RED)
                btnSave.background = GradientDrawable().apply {
                    cornerRadius = 10f; setColor(Color.BLACK); setStroke(3, Color.parseColor("#CC0000"))
                }
            }
            if (::ipAdapter.isInitialized) ipAdapter.notifyDataSetChanged()
        }
    }

    private fun enviarTCP(comando: String) {
        if (watchoutIP.isEmpty()) return
        val cmdFinal = "$comando\r\n"
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Socket().use { socket ->
                    socket.tcpNoDelay = true
                    socket.connect(InetSocketAddress(watchoutIP, tcpPort), 1000)
                    socket.outputStream.write(cmdFinal.toByteArray(Charsets.US_ASCII))
                    socket.outputStream.flush()
                }
            } catch (e: Exception) { }
        }
    }

    private fun startStreaming() {
        streamJob?.cancel()
        streamJob = CoroutineScope(Dispatchers.IO).launch {
            val url = "http://$watchoutIP:$apiPort/v2/ndjson"
            try {
                val request = Request.Builder().url(url).header("Accept", "application/x-ndjson").build()
                ndjsonClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@use
                    val source = response.body?.source() ?: return@use
                    lastEventTime = System.currentTimeMillis()
                    
                    while (isActive && !source.exhausted()) {
                        val line = source.readUtf8Line() ?: break
                        if (line.isNotBlank()) {
                            lastEventTime = System.currentTimeMillis()
                            processarLine(line)
                        }
                    }
                }
            } catch (e: Exception) {
                delay(2000)
                if (isConnected) startStreaming()
            }
        }
    }

    private fun startWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                delay(5000)
                if (isConnected && System.currentTimeMillis() - lastEventTime > 8000) {
                    startStreaming()
                }
            }
        }
    }

    private fun processarLine(line: String) {
        try {
            val json = JSONObject(line)
            when (json.optString("kind")) {
                "timelineCountdowns" -> processarCountdowns(json.optJSONArray("value"))
                "playbackState" -> processarState(json.optJSONObject("value"), false)
            }
        } catch (e: Exception) { }
    }

    private fun processarState(value: JSONObject?, isFullState: Boolean) {
        if (value == null) return
        val timelines = value.optJSONArray("timelines") ?: return
        
        val statusUpdates = mutableMapOf<String, String>()
        val audioUpdates = mutableMapOf<String, Boolean>()
        
        if (isFullState) {
            currentStatusMap.keys.forEach { currentStatusMap[it] = "stop" }
            currentAudioMap.clear()
        }

        for (i in 0 until timelines.length()) {
            val t = timelines.optJSONObject(i) ?: continue
            val id = t.optString("id").trim()
            val name = t.optString("name").trim().ifEmpty { idToNameMap[id] ?: "" }
            val status = t.optString("playbackStatus", "stop").lowercase()
            
            val hasAudio = t.optDouble("volume", 0.0) > 0 || t.optBoolean("audio", false)
            
            if (name.isNotEmpty()) {
                statusUpdates[name] = status
                audioUpdates[name] = hasAudio
            }
            if (id.isNotEmpty()) {
                statusUpdates[id] = status
                audioUpdates[id] = hasAudio
            }
            
            if (status == "stop") {
                countdownMap.remove(name)
                countdownMap.remove(id)
            }
        }
        runOnUiThread {
            currentStatusMap.putAll(statusUpdates)
            currentAudioMap.putAll(audioUpdates)
            atualizarEstiloDosBotoes()
        }
    }

    private fun processarCountdowns(values: JSONArray?) {
        val newMap = mutableMapOf<String, String>()
        if (values != null) {
            for (i in 0 until values.length()) {
                val obj = values.optJSONObject(i) ?: continue
                val id = obj.optString("timelineId").trim()
                val name = obj.optString("timelineName").trim().ifEmpty { idToNameMap[id] ?: "" }
                val cue = obj.optString("cueName").trim()
                val delta = obj.optLong("delta")

                if (delta < -100) {
                    val absDelta = abs(delta)
                    val timeStr = formatTime(absDelta)
                    val display = if (cue.isNotEmpty()) "$cue: $timeStr" else timeStr
                    if (name.isNotEmpty()) newMap[name] = display
                    if (id.isNotEmpty()) newMap[id] = display
                }
            }
        }

        runOnUiThread {
            val currentKeys = countdownMap.keys.toSet()
            newMap.forEach { (k, v) -> countdownMap[k] = v }
            currentKeys.forEach { if (!newMap.containsKey(it)) countdownMap.remove(it) }
            atualizarEstiloDosBotoes()
        }
    }

    private fun refreshTimelines() {
        if (refreshJob?.isActive == true) return
        refreshJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val tUrl = "http://$watchoutIP:$apiPort/v0/timelines"
                val sUrl = "http://$watchoutIP:$apiPort/v1/state"
                
                val tJob = async { try { apiClient.newCall(Request.Builder().url(tUrl).build()).execute().use { it.body?.string() } } catch(e: Exception) { null } }
                val sJob = async { try { apiClient.newCall(Request.Builder().url(sUrl).build()).execute().use { it.body?.string() } } catch(e: Exception) { null } }

                val tJson = tJob.await()
                val sJson = sJob.await()

                withContext(Dispatchers.Main) {
                    if (tJson != null) {
                        isConnected = true
                        processarBotoes(tJson, sJson)
                        findViewById<View>(R.id.layout_error)?.visibility = View.GONE
                        findViewById<View>(R.id.scroll_container)?.visibility = View.VISIBLE
                    } else {
                        isConnected = false
                        findViewById<View>(R.id.layout_error)?.visibility = View.VISIBLE
                        findViewById<View>(R.id.scroll_container)?.visibility = View.GONE
                    }
                    atualizarStatusUI()
                }
            } catch (e: Exception) { }
        }
    }

    private fun processarBotoes(timelinesJson: String, stateJson: String?) {
        val grid = findViewById<GridLayout>(R.id.grid_botoes) ?: return
        
        val tempNameToId = mutableMapOf<String, String>()
        val tempIdToName = mutableMapOf<String, String>()

        if (!stateJson.isNullOrBlank()) {
            try {
                val obj = JSONObject(stateJson)
                val stateArray = obj.optJSONArray("timelines") ?: JSONArray()
                for (i in 0 until stateArray.length()) {
                    val t = stateArray.optJSONObject(i) ?: continue
                    val name = t.optString("name").trim()
                    val id = t.optString("id").trim()
                    if (name.isNotEmpty() && id.isNotEmpty()) {
                        tempNameToId[name] = id
                        tempIdToName[id] = name
                    }
                }
                processarState(obj, true)
            } catch (e: Exception) { }
        }

        try {
            val timelinesArray = if (timelinesJson.trim().startsWith("[")) JSONArray(timelinesJson) else JSONObject(timelinesJson).optJSONArray("timelines") ?: JSONArray()
            val currentNames = mutableListOf<String>()
            
            for (i in 0 until timelinesArray.length()) {
                val obj = timelinesArray.optJSONObject(i) ?: continue
                val name = obj.optString("name").trim()
                val id = obj.optString("id").trim()
                
                if (name.isNotEmpty() && id.isNotEmpty()) {
                    tempNameToId[name] = id
                    tempIdToName[id] = name
                }

                if (name.equals("Main Timeline", ignoreCase = true)) continue
                if (name.isBlank()) continue
                
                currentNames.add(name)
            }

            nameToIdMap.clear(); nameToIdMap.putAll(tempNameToId)
            idToNameMap.clear(); idToNameMap.putAll(tempIdToName)

            if (currentNames != botoesAtivos.keys.toList()) {
                grid.removeAllViews()
                botoesAtivos.clear()
                val hPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 85f, resources.displayMetrics).toInt()
                val mPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 8f, resources.displayMetrics).toInt()

                for (name in currentNames) {
                    val btn = AppCompatButton(this).apply {
                        text = name; isAllCaps = false; setLineSpacing(0f, 0.9f)
                        TextViewCompat.setAutoSizeTextTypeWithDefaults(this, TextViewCompat.AUTO_SIZE_TEXT_TYPE_UNIFORM)
                        TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(this, 10, 24, 1, TypedValue.COMPLEX_UNIT_SP)
                        layoutParams = GridLayout.LayoutParams().apply {
                            width = 0; height = hPx; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(mPx, mPx, mPx, mPx)
                        }
                        setOnClickListener { it.bounce(); lastPressedName = name; atualizarEstiloDosBotoes(); enviarTCP("run \"$name\"") }
                    }
                    grid.addView(btn)
                    botoesAtivos[name] = btn
                }
            } else {
                nameToIdMap.putAll(tempNameToId)
                idToNameMap.putAll(tempIdToName)
            }
            atualizarEstiloDosBotoes()
        } catch (e: Exception) { }
    }

    private fun atualizarEstiloDosBotoes() {
        val btnStop = findViewById<Button>(R.id.btn_stop_all)
        val btnMain = findViewById<Button>(R.id.btn_main_timeline)
        val isPanicLast = lastPressedName == "PANIC"
        
        val panicTag = "$isPanicLast|${btnStop?.visibility}"
        if (btnStop?.tag != panicTag) {
            btnStop?.tag = panicTag
            btnStop?.background = GradientDrawable().apply {
                cornerRadius = 30f; setColor(Color.parseColor("#CC0000"))
                setStroke(10, if (isPanicLast) Color.YELLOW else Color.WHITE)
            }
            btnStop?.setTextColor(if (isPanicLast) Color.YELLOW else Color.WHITE)
        }

        btnMain?.let { applyStyleToButton(it, "Main Timeline") }

        for ((name, btn) in botoesAtivos) {
            applyStyleToButton(btn, name)
        }
    }

    private fun applyStyleToButton(btn: Button, name: String) {
        val id = nameToIdMap[name] ?: ""
        val status = currentStatusMap[name] ?: currentStatusMap[id] ?: "stop"
        val hasAudio = currentAudioMap[name] ?: currentAudioMap[id] ?: false
        val timeRemaining = if (status != "stop") (countdownMap[name] ?: countdownMap[id]) else null
        
        val isRunning = status == "run"
        val isPaused = status == "pause"
        val isLast = (name == lastPressedName)
        val isVisualActive = isRunning || timeRemaining != null

        val symbol = when(status) {
            "run" -> " ▶"
            "pause" -> " ⏸"
            else -> ""
        }
        val audioSymbol = if (hasAudio) " 🔊" else ""

        val newText = if (timeRemaining != null) "$name$symbol$audioSymbol\n$timeRemaining" else "$name$symbol$audioSymbol"
        val stateTag = "$newText|$status|$isLast|$isVisualActive|$hasAudio"

        if (btn.tag != stateTag) {
            btn.tag = stateTag
            btn.text = newText
            btn.setTextColor(if (isLast) Color.YELLOW else if (isVisualActive) Color.WHITE else Color.parseColor("#CC00FF"))
            btn.setTypeface(null, if (isVisualActive || isPaused || isLast) Typeface.BOLD else Typeface.NORMAL)
            
            btn.background = GradientDrawable().apply {
                cornerRadius = if (isVisualActive) 100f else 30f
                val bgColor = when {
                    isVisualActive -> Color.parseColor("#006400")
                    isPaused -> Color.parseColor("#000044")
                    else -> Color.BLACK
                }
                setColor(bgColor)
                val strokeColor = when {
                    isLast -> Color.YELLOW
                    isVisualActive -> Color.MAGENTA
                    isPaused -> Color.CYAN
                    else -> Color.parseColor("#440077")
                }
                setStroke(if (isLast) 10 else 6, strokeColor)
            }
        }
    }

    private fun startAutoRefresh() {
        autoRefreshJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                refreshTimelines()
                delay(1000)
            }
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSecs = ms / 1000
        val minutes = totalSecs / 60
        val seconds = totalSecs % 60
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
    }

    private fun startDiscovery() {
        discoveryJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val socket = DatagramSocket(null).apply { reuseAddress = true; broadcast = true; bind(InetSocketAddress(3040)) }
                val buffer = ByteArray(1024)
                while (isActive) {
                    val packet = DatagramPacket(buffer, buffer.size); socket.receive(packet)
                    val ip = packet.address.hostAddress
                    if (ip != null && !listaIPs.contains(ip)) {
                        withContext(Dispatchers.Main) { 
                            if (!listaIPs.contains(ip)) { 
                                listaIPs.add(ip)
                                ipAdapter.notifyDataSetChanged()
                            } 
                        }
                    }
                }
            } catch (e: Exception) { }
        }
    }

    private fun buscarInstanciasAtivas() {
        CoroutineScope(Dispatchers.IO).launch {
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ipInt = wifi.connectionInfo.ipAddress
            if (ipInt == 0) return@launch
            val subnet = String.format(Locale.getDefault(), "%d.%d.%d", (ipInt and 0xff), (ipInt shr 8 and 0xff), (ipInt shr 16 and 0xff))
            for (i in 1..254) {
                launch {
                    val ipTeste = "$subnet.$i"
                    try { Socket().use { s -> s.connect(InetSocketAddress(ipTeste, tcpPort), 100)
                        withContext(Dispatchers.Main) { 
                            if (!listaIPs.contains(ipTeste)) { 
                                listaIPs.add(ipTeste)
                                ipAdapter.notifyDataSetChanged()
                            } 
                        } }
                    } catch (e: Exception) { }
                }
            }
        }
    }

    private fun hideSystemUI() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    private fun View.bounce() {
        this.animate().scaleX(1.1f).scaleY(1.1f).setDuration(100).withEndAction {
            this.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start()
        }.start()
    }

    override fun onDestroy() { 
        autoRefreshJob?.cancel()
        streamJob?.cancel()
        watchdogJob?.cancel()
        unregisterReceiver(batteryReceiver)
        super.onDestroy() 
    }
}
